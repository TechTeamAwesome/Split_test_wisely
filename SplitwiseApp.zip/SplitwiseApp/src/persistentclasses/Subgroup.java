package persistentclasses;

public class Subgroup {
	
	String groupId;
	String memberId;
	String totalOfEachMemberinGroup;
	
	public Subgroup() {
		
	}
	
	public Subgroup(String groupId, String memberId, String totalOfEachMemberinGroup) {
		super();
		this.groupId = groupId;
		this.memberId = memberId;
		this.totalOfEachMemberinGroup = totalOfEachMemberinGroup;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getTotalOfEachMemberinGroup() {
		return totalOfEachMemberinGroup;
	}
	public void setTotalOfEachMemberinGroup(String totalOfEachMemberinGroup) {
		this.totalOfEachMemberinGroup = totalOfEachMemberinGroup;
	}
	
	
	
	

}
