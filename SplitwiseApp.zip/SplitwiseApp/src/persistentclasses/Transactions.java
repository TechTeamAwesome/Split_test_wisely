package persistentclasses;

public class Transactions {
	String transactionId;
	String groupId;
	String memberId;
	String description;
	double amount;
	
	public Transactions() {
		
	}
	
	public Transactions(String transactionId, String groupId, String memberId, String description, double amount) {
		super();
		this.transactionId = transactionId;
		this.groupId = groupId;
		this.memberId = memberId;
		this.description = description;
		this.amount = amount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
}
