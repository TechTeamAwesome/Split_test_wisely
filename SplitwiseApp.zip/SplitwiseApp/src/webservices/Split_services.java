package webservices;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import servicesinit.Split_init;

@Path("/user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class Split_services {
	
Split_init splitinit =new Split_init();

	@Path("/login")
	@GET
	public String login()
	{
		return splitinit.login();
	}
	
	@Path("/addgroups")
	@POST
	public String addGroup()
	{
		return splitinit.addGroup();
	}
	
	@Path("/addMember")
	@POST
	public String addMember()
	{
		return splitinit.addGroup();
	}
	
	@Path("/addExpense")
	@POST
	public String addExpense()
	{
		return splitinit.addExpense();
	}
	
	
	@Path("/addgroups")
	@POST
	public String addTransaction()
	{
		return splitinit.addTransction();
	}
	
	
	

}
