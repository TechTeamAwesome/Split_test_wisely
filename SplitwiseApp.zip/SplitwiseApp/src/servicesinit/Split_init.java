package servicesinit;

public class Split_init {
	
	public String addUsers()
	{
		return "useradded";
	}
	
	public String login()
	{
		return "successful";
	}
	
	public String addGroup() 
	{
		return "groupadded";
	}
	
	public String addMember()
	{
		return "memberadded";
	}
	
	public String addExpense() 
	{
		return "Expenseadded";
	}
	
	public String settleup() 
	{
		return "settledup";
	}
	
	public String addTransction() 
	{
		return "transcationAdded";
	}
}
