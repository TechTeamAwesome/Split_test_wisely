package persistentUtil;
import java.sql.*;

import persistentclasses.*;
public class DatabaseUtility {

	private static Connection con=null;
	static String query;
	static String type;
    static PreparedStatement stt=null;
    static ResultSet rst=null;
	static {
		con=DatabaseConnection.connect();
	       }
	//Insert by passing the object
	/* For eg. Add a group
	 * Group ob=new Group("1","Demo","10000");
	 * DatabaseUtiltiy.insert(ob);
	 */
	public static boolean insert(Object ob)
	{
		type=ob.getClass().getSimpleName();
		if(type.equals("Users"))
		{
			Users user=(Users) ob;
			query="Insert into "+type+" (phoneNumber,userName,password,userId) values "+
			"('"+user.getPhoneNumber()+"','"+user.getUserName()+"','"+user.getPassword()+"','"+user.getUserId()+"')";
					}
		else if(type.equals("Group1"))
		{
			Group group=(Group) ob;
			query="INSERT INTO Group1 (groupId,groupName,groupTotal) Values"+
			"('"+group.getGroupId()+"','"+group.getGroupName()+"','"+group.getGroupTotal()+"')";
		}
		else if(type.equals("Subgroup"))
		{
			Subgroup subgroup=(Subgroup) ob;
			query="insert into "+type+" (groupId,memberId,totalOfEachMemberinGroup) values"+
			      "('"+subgroup.getGroupId()+"','"+subgroup.getMemberId()+"','"+subgroup.getTotalOfEachMemberinGroup()+"')";
		}
		else if(type.equals("Member"))
		{
			Member member=(Member)ob;
			query="insert into "+type+" (userId,friendId,groupId,ownes,debt) values"+
			      "('"+member.getUserId()+"','"+member.getFriendId()+"','"+member.getGroupId()+"','"+member.getOwnes()+"','"+member.getDebt()+"')";
		}
		else if(type.equals("Transactions"))
		{
			Transactions transaction=(Transactions)ob;
			query="insert into "+type+" (transactionId,groupId,memberId,description,amount) values"+
			      "('"+transaction.getTransactionId()+"','"+transaction.getGroupId()+"','"+transaction.getMemberId()+"','"+transaction.getDescription()+"','"+transaction.getAmount()+"') ";
		}
		else return false;
		
		try{
			stt=con.prepareStatement(query);
			return stt.execute();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}

		
	}
	//Update by passing the object
		/* For eg. Update a group
		 * Group ob=new Group("1","Updated_Demo","100");
		 * DatabaseUtiltiy.update(ob);
		 */
	public static boolean update(Object ob)
	{ 
		type=ob.getClass().getSimpleName();
		if(type.equals("Users"))
		{
			Users user=(Users)ob;
			String phoneNumber=user.getPhoneNumber();
			String userName;
			String password;
			String userId;
			query="select * From Users Where phoneNumber='"+phoneNumber+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 userName=rst.getString(2);
					 password=rst.getString(3);
					 userId=rst.getString(4);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(userName!=user.getUserName())
			{	 
				query="update Users set userName ='"+user.getUserName()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(password!=user.getPassword())
			{	 
				query="update Users set password ='"+user.getPassword()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(userId!=user.getUserId())
			{	 
				query="update Users set userId ='"+user.getUserId()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
		}
		else if(type.equals("Group1"))
		{
			Group group=(Group) ob;
			String groupName;
			String groupTotal;
			String groupId=group.getGroupId();
			query="select * From Group1 Where groupId='"+groupId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 groupName=rst.getString(2);
					 groupTotal=rst.getString(3);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(groupName!=group.getGroupName())
			{	 
				query="update Group1 set groupName ='"+group.getGroupName()+"' where groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(groupTotal!=group.getGroupTotal())
			{	 
				query="update Group1 set groupTotal ='"+group.getGroupTotal()+"' where groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			}
			return true;
		}
		else if(type.equals("Subgroup"))
		{
			Subgroup subgroup=(Subgroup) ob;
			String groupId=subgroup.getGroupId();
			String memberId=subgroup.getMemberId();
			String totalOfEachMemberinGroup;
			query="select * From Subgroup Where groupId='"+groupId+"' AND memberId='"+memberId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 totalOfEachMemberinGroup=rst.getString(3);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(totalOfEachMemberinGroup!=subgroup.getTotalOfEachMemberinGroup())
			{	 
				query="update Subgroup set totalOfEachMemberinGroup ='"+subgroup.getTotalOfEachMemberinGroup()+"' where groupId='"+groupId+"' and memberId='"+memberId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					return true;
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
			
		}
		else if(type.equals("Member"))
		{
			Member member=(Member) ob;
			String userId=member.getUserId();
			String friendId=member.getFriendId();
			String groupId=member.getGroupId();
			String ownes,debt;
			query="select * From Member Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 ownes=rst.getString(4);
					 debt=rst.getString(5);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(Double.parseDouble(ownes)!=member.getOwnes())
			{	 
				query="update Member set ownes ='"+member.getOwnes()+"' Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
				
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(Double.parseDouble(debt)!=member.getDebt())
			{	 
				query="update Member set debt ='"+member.getDebt()+"' Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					return true;
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
		}
		else if(type.equals("Transactions"))
		{
			Transactions transaction=(Transactions) ob;
			String transactionId=transaction.getTransactionId();
			String groupId;
			String memberId;
			String description;
			String amount;
			query="select * From Transactions Where transactionId='"+transactionId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 groupId=rst.getString(2);
					 memberId=rst.getString(3);
				     description=rst.getString(4);
				     amount=rst.getString(5);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(groupId!=transaction.getGroupId())
			{	 
				query="update Transactions set groupId ='"+transaction.getGroupId()+"'Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(memberId!=transaction.getMemberId())
			{	 
				query="update Transactions set memberId ='"+transaction.getMemberId()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(description!=transaction.getDescription())
			{	 
				query="update Transactions set description ='"+transaction.getDescription()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(Double.parseDouble(amount)!=transaction.getAmount())
			{	 
				query="update Transactions set amount ='"+transaction.getAmount()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			
			return true;
		}
		
		
		return false;
	}
}
