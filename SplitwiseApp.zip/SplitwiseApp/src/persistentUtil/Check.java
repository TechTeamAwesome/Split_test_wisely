package persistentUtil;
import persistentclasses.*;
import sun.security.util.Password;
public class Check {
   
	public static void main(String[] args) {
		
		Users user=new Users("9873681161","Anubhav","dnandnm","anubh94.aice@gmail.com");
		//Group1 group1=new Group1("12345","FunFun","1000");
		//Subgroup subgroup=new Subgroup("1234","987364111","900000");
		//Member subgroup1=new Member("9873641180","9999999999","123",0,0);
		//Transactions subgroup2=new Transactions("10","10","10","10",10);
		 DatabaseUtility.insert(user);
		

	}

}
