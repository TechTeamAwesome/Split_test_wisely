package persistentUtil;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

	public static Connection connect() {
		
		  String url= "jdbc:mysql://localhost/split";
		  String user="root";
		  String password= "";
				   try
				   {
					   Class.forName("com.mysql.jdbc.Driver").newInstance();
					   Connection con=DriverManager.getConnection(url, user, password);
					   System.out.println("connection successful");
					   return con;
				   }
				   catch(Exception e)
				   {
					   e.printStackTrace();
					   return null;
				   }
			}
}
