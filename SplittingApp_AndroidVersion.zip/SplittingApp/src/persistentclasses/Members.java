package persistentclasses;

public class Members {
	
	String groupId;
	String memberId;
	String totalOfEachMemberinGroup;
	String currenttotalOfEachMemberinGroup;
	
	public Members() {
		
	}
	
	public Members(String groupId, String memberId, String totalOfEachMemberinGroup,
			String currenttotalOfEachMemberinGroup) {
		super();
		this.groupId = groupId;
		this.memberId = memberId;
		this.totalOfEachMemberinGroup = totalOfEachMemberinGroup;
		this.currenttotalOfEachMemberinGroup = currenttotalOfEachMemberinGroup;
	}
	public String getCurrenttotalOfEachMemberinGroup() {
		return currenttotalOfEachMemberinGroup;
	}
	public void setCurrenttotalOfEachMemberinGroup(String currenttotalOfEachMemberinGroup) {
		this.currenttotalOfEachMemberinGroup = currenttotalOfEachMemberinGroup;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getTotalOfEachMemberinGroup() {
		return totalOfEachMemberinGroup;
	}
	public void setTotalOfEachMemberinGroup(String totalOfEachMemberinGroup) {
		this.totalOfEachMemberinGroup = totalOfEachMemberinGroup;
	}
	
	
	
	

}
