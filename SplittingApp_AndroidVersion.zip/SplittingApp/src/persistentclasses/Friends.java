package persistentclasses;

public class Friends {
	
	String userId;
	String friendId;
	String groupId;
	double ownes;
	double debt;
	
	public Friends() {
		
	}
	
	public Friends(String userId, String friendId, String groupId, double ownes, double debt) {
		super();
		this.userId = userId;
		this.friendId = friendId;
		this.groupId = groupId;
		this.ownes = ownes;
		this.debt = debt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFriendId() {
		return friendId;
	}
	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public double getOwnes() {
		return ownes;
	}
	public void setOwnes(double ownes) {
		this.ownes = ownes;
	}
	public double getDebt() {
		return debt;
	}
	public void setDebt(double debt) {
		this.debt = debt;
	}
	
	
	
	
}
