package servicesImpl;

import persistentclasses.Friends;
import persistentclasses.Group;
import persistentclasses.Members;
import persistentclasses.Transactions;
import persistentclasses.Users;
import response.ResponseGroup;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;

import models.AuthModel;
import persistentUtil.DatabaseUtility;
import persistentUtil.LocalCache;

public class Split_impl {

	private static Map<Long, AuthModel> authmodel = LocalCache.getUser();

	public boolean addUsers(String phonenumber, String username, String password, String email) 
	{
		Users u = new Users();
		u.setPassword(password);
		u.setPhoneNumber(phonenumber);
		u.setUserId(email);
		u.setUserName(username);
		DatabaseUtility.insert(u);
		return true;
	}

	public long getsessionid() {
		Random randomno = new Random();
		long value = randomno.nextLong();
		return value;
	}

	public long login(String userId, String password) {

		if (Authenticate(userId, password)) {
			long sessionid = getsessionid();
			AuthModel am = new AuthModel();
			am.setUserid(userId);
			System.out.println(sessionid);
			System.out.println(am);
			authmodel.put(sessionid, am);
			return sessionid;
		}

		return -1;
	}

	public boolean Authenticate(String userId, String password) {
		System.out.println(userId + password);
		// try - null return when wrong id
		Users u = DatabaseUtility.getUser(userId);
		String passwrd = u.getPassword();
		System.out.println(passwrd);
		if (passwrd.equals(password))
			return true;
		else
			return false;
	}

	public ResponseGroup addGroup(String groupName, List<Long> groupMembers, long sessionId) 
	{
		ResponseGroup groupDetails = new ResponseGroup();
		if (AuthenticateSession(sessionId)) {
			String userId = LocalCache.getuseridfromSessionId(sessionId);
			String groupID = String.valueOf(DatabaseUtility.getGroupIDCounter());
			DatabaseUtility.setGroupIDCounter(DatabaseUtility.getGroupIDCounter() + 1);
			Group group = new Group(groupID, groupName, "0");
			DatabaseUtility.insert(group);
			ListIterator<Long> listiterator = groupMembers.listIterator();
			while (listiterator.hasNext()) {
				if (addMember(groupID, listiterator.next().toString(), sessionId))
					continue;
				// else
				// throw exception
			}
						
			ListIterator<Long> listiterator1 = groupMembers.listIterator();
			List<String> groupMembersName = new ArrayList<String>();
			
			while (listiterator1.hasNext()) 
			{
				Users u = new Users();
				u = DatabaseUtility.getUser(listiterator1.next().toString());
				groupMembersName.add(u.getUserName());		
			}
									
			groupDetails.setGroupName(groupName);
			groupDetails.setGroupMembers(groupMembersName);
			groupDetails.setGroupTotal("0.0");
			groupDetails.setResponse("OK");
			
			
		} 
		else
		{
			groupDetails.setResponse("NOT OK");
		}
		return groupDetails;
	}

	public String addExpense(long sessionId, String groupId,String description, double amount,List<Long> groupMembers, String splitcategory) 
	{
		
		if(AuthenticateSession(sessionId))
		{
			String memberId = LocalCache.getuseridfromSessionId(sessionId);	
		
			String transactionId = String.valueOf(DatabaseUtility.getTransactionIdCounter());
			DatabaseUtility.setTransactionIdCounter(DatabaseUtility.getTransactionIdCounter() + 1);
			Group group;
			group=DatabaseUtility.getGroup(groupId);
			Double updatedamount=Double.parseDouble(group.getGroupTotal())+amount;
			group.setGroupTotal(updatedamount.toString());
			DatabaseUtility.update(group);
			
			
			Members member;
			member=DatabaseUtility.getMember(groupId, memberId);
			Double updatedMemberamount=Double.parseDouble(member.getTotalOfEachMemberinGroup()+amount);
			member.setTotalOfEachMemberinGroup(updatedMemberamount.toString());
			DatabaseUtility.update(member);
			
			
			ListIterator<Long> listiterator = groupMembers.listIterator();
			double individualAmount=amount/(groupMembers.size()+1);
			while(listiterator.hasNext())
			{
				
				String temp=listiterator.next().toString();
				System.out.println("temp"+temp);
				Friends friend1=DatabaseUtility.getFriend(memberId,temp,groupId);
				double value = friend1.getOwnes()+individualAmount;
			    double valueRounded = Math.round(value * 100D) / 100D;
				friend1.setOwnes(valueRounded);
			
				DatabaseUtility.update(friend1);
			}
			ListIterator<Long> listiterator1 = groupMembers.listIterator();
			while(listiterator1.hasNext())
			{
				
				String temp=listiterator1.next().toString();
				System.out.println("temp"+temp);
				Friends friend1=DatabaseUtility.getFriend(temp,memberId,groupId);
				double value = friend1.getDebt()+individualAmount;
			    double valueRounded = Math.round(value * 100D) / 100D;
				friend1.setDebt(valueRounded);
			
				DatabaseUtility.update(friend1);
			}
			
			
			Transactions expenses = new Transactions(transactionId, groupId, memberId, description, amount);
			
			DatabaseUtility.insert(expenses);
			
			return "Expense added";
			}
			else 
			{
			return "Expense not added";
			}
				
		}

	public String settleup() {
		return "settledup";
	}

	public String addTransction() {
		return "transcationAdded";
	}

	public boolean AuthenticateSession(long sessionid) {
		if (authmodel.get(sessionid).equals(null))
			return false;
		else
			return true;
	}

	public boolean addMember(String groupId, String memberId, long sessionId) {
		if (AuthenticateSession(sessionId)) {
			String userId = LocalCache.getuseridfromSessionId(sessionId);
			String Query = "Select * from Members where groupId ='" + groupId + "'";
			ResultSet rs = DatabaseUtility.get(Query);
			System.out.println(rs);
			try {
				while (rs.next()) {
					String getmember = rs.getString(2);
					Friends f1 = new Friends(memberId, getmember, groupId, 0, 0);
					Friends f2 = new Friends(getmember, memberId, groupId, 0, 0);
					DatabaseUtility.insert(f1);
					DatabaseUtility.insert(f2);
				}
			} catch (Exception e) {
				e.getStackTrace();
			}
			Members member = new Members(groupId, memberId, "0","0");
			DatabaseUtility.insert(member);
			return true;
		} else
			// throws exception
			return false;
	}
}
