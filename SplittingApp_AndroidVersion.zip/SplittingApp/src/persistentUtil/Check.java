package persistentUtil;
import java.sql.ResultSet;
import java.sql.SQLException;

import persistentclasses.*;
import sun.security.util.Password;
public class Check {
	
	
	public static void main(String[] args) throws SQLException {
		
		//Users user=new Users("9873681161","AnubhavGupta","dnandnm","anubh94.aice@gmail.com");
		//Group u=new Group("12345","FunFunFun","1000");
		//Members subgroup=new Members("1234","987364111","0");
		Friends subgroup1=DatabaseUtility.getFriend("1234567999","1234598765","1");
		System.out.println(subgroup1.getOwnes());
		//Transactions subgroup2=new Transactions("10","0","0","0",0);
		 
		// Group u=DatabaseUtility.getGroup("12345");
		/*System.out.println(u.getGroupId().toString());
		System.out.println(u.getGroupName().toString());
		
		String query="select * from users";
		ResultSet rs = DatabaseUtility.get(query);
		while(rs.next()){
			System.out.println(rs.getString(2));
		}
		*/
	}

}
