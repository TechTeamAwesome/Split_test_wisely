package persistentUtil;
import java.sql.*;

import persistentclasses.*;
public class DatabaseUtility {

	private static Connection con=null;
	static String query;
	static String type;
    static PreparedStatement stt=null;
    static ResultSet rst=null;
    private static int groupIDCounter;
    private static int transactionIdCounter;

    
	static {
		con=DatabaseConnection.connect();
		groupIDCounter=0;
	       }
	//Insert by passing the object
	/* For eg. Add a group
	 * Group ob=new Group("1","Demo","10000");
	 * DatabaseUtiltiy.insert(ob);
	 */
	
	public static int getTransactionIdCounter() 
	{
		return transactionIdCounter;
	}
	public static void setTransactionIdCounter(int transactionIdCounter) 
	{
		DatabaseUtility.transactionIdCounter = transactionIdCounter;
	}
	public static int getGroupIDCounter() {
		return groupIDCounter;
	}
	
	public static void setGroupIDCounter(int groupIDCounter) {
		DatabaseUtility.groupIDCounter = groupIDCounter;
	}

	public static boolean insert(Object ob)
	{
		type=ob.getClass().getSimpleName();
		if(type.equals("Users"))
		{
			Users user=(Users) ob;
			query="Insert into "+type+" (phoneNumber,userName,password,userId) values "+
			"('"+user.getPhoneNumber()+"','"+user.getUserName()+"','"+user.getPassword()+"','"+user.getUserId()+"')";
					}
		else if(type.equals("Group"))
		{
			Group group=(Group) ob;
			query="INSERT INTO Group1 (groupId,groupName,groupTotal) Values"+
			"('"+group.getGroupId()+"','"+group.getGroupName()+"','"+group.getGroupTotal()+"')";
		}
		else if(type.equals("Members"))
		{
			Members subgroup=(Members) ob;
			query="insert into "+type+" (groupId,memberId,totalOfEachMemberinGroup,currenttotalOfEachMemberinGroup) values"+
			      "('"+subgroup.getGroupId()+"','"+subgroup.getMemberId()+"','"+subgroup.getTotalOfEachMemberinGroup()+"','"+subgroup.getCurrenttotalOfEachMemberinGroup()+"')";
		}
		else if(type.equals("Friends"))
		{
			Friends member=(Friends)ob;
			query="insert into "+type+" (userId,friendId,groupId,ownes,debt) values"+
			      "('"+member.getUserId()+"','"+member.getFriendId()+"','"+member.getGroupId()+"','"+member.getOwnes()+"','"+member.getDebt()+"')";
		}
		else if(type.equals("Transactions"))
		{
			Transactions transaction=(Transactions)ob;
			query="insert into "+type+" (transactionId,groupId,memberId,description,amount) values"+
			      "('"+transaction.getTransactionId()+"','"+transaction.getGroupId()+"','"+transaction.getMemberId()+"','"+transaction.getDescription()+"','"+transaction.getAmount()+"') ";
		}
		else return false;
		
		try{
			stt=con.prepareStatement(query);
			return stt.execute();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}

		
	}
	//Update by passing the object
		/* For eg. Update a group
		 * Group ob=new Group("1","Updated_Demo","100");
		 * DatabaseUtiltiy.update(ob);
		 */
	public static boolean update(Object ob)
	{ 
		type=ob.getClass().getSimpleName();
		if(type.equals("Users"))
		{
			Users user=(Users)ob;
			String phoneNumber=user.getPhoneNumber();
			String userName;
			String password;
			String userId;
			query="select * From Users Where phoneNumber='"+phoneNumber+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 userName=rst.getString(2);
					 password=rst.getString(3);
					 userId=rst.getString(4);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(!(userName.equals(user.getUserName())))
			{	 
				query="update Users set userName ='"+user.getUserName()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(password.equals(user.getPassword())))
			{	 
				query="update Users set password ='"+user.getPassword()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(userId.equals(user.getUserId())))
			{	 
				query="update Users set userId ='"+user.getUserId()+"'Where phoneNumber='"+phoneNumber+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
		}
		else if(type.equals("Group"))
		{
			Group group=(Group) ob;
			String groupName;
			String groupTotal;
			String groupId=group.getGroupId();
			query="select * From Group1 Where groupId='"+groupId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 groupName=rst.getString(2);
					 groupTotal=rst.getString(3);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(!(groupName.equals(group.getGroupName())))
			{	 
				query="update Group1 set groupName ='"+group.getGroupName()+"' where groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(groupTotal.equals(group.getGroupTotal())))
			{	 
				query="update Group1 set groupTotal ='"+group.getGroupTotal()+"' where groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			}
			return true;
		}
		else if(type.equals("Members"))
		{
			Members subgroup=(Members) ob;
			String groupId=subgroup.getGroupId();
			String memberId=subgroup.getMemberId();
			String totalOfEachMemberinGroup;
			String currenttotalOfEachMemberinGroup;
			query="select * From Members Where groupId='"+groupId+"' AND memberId='"+memberId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 totalOfEachMemberinGroup=rst.getString(3);
					 currenttotalOfEachMemberinGroup=rst.getString(4);
					 
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(!(totalOfEachMemberinGroup.equals(subgroup.getTotalOfEachMemberinGroup())))
			{	 
				query="update Members set totalOfEachMemberinGroup ='"+subgroup.getTotalOfEachMemberinGroup()+"' where groupId='"+groupId+"' and memberId='"+memberId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
			
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(currenttotalOfEachMemberinGroup.equals(subgroup.getCurrenttotalOfEachMemberinGroup())))
			{	 
				query="update Members set currenttotalOfEachMemberinGroup ='"+subgroup.getCurrenttotalOfEachMemberinGroup()+"' where groupId='"+groupId+"' and memberId='"+memberId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
		
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
			
		}
		else if(type.equals("Friends"))
		{
			Friends member=(Friends) ob;
			String userId=member.getUserId();
			String friendId=member.getFriendId();
			String groupId=member.getGroupId();
			String ownes,debt;
			query="select * From Friends Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 ownes=rst.getString(4);
					 debt=rst.getString(5);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(Double.parseDouble(ownes)!=member.getOwnes())
			{	 
				query="update Friends set ownes ='"+member.getOwnes()+"' Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
				
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(Double.parseDouble(debt)!=member.getDebt())
			{	 
				query="update Friends set debt ='"+member.getDebt()+"' Where userId='"+userId+"' AND friendId='"+friendId+"' AND groupId='"+groupId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					return true;
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			return true;
		}
		else if(type.equals("Transactions"))
		{
			Transactions transaction=(Transactions) ob;
			String transactionId=transaction.getTransactionId();
			String groupId;
			String memberId;
			String description;
			String amount;
			query="select * From Transactions Where transactionId='"+transactionId+"'";
			try{
				stt=con.prepareStatement(query);
				 rst=stt.executeQuery();
				     rst.next();
					 groupId=rst.getString(2);
					 memberId=rst.getString(3);
				     description=rst.getString(4);
				     amount=rst.getString(5);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return false;
				}
			
			if(!(groupId.equals(transaction.getGroupId())))
			{	 
				query="update Transactions set groupId ='"+transaction.getGroupId()+"'Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(memberId.equals(transaction.getMemberId())))
			{	 
				query="update Transactions set memberId ='"+transaction.getMemberId()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(!(description.equals(transaction.getDescription())))
			{	 
				query="update Transactions set description ='"+transaction.getDescription()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			if(Double.parseDouble(amount)!=transaction.getAmount())
			{	 
				query="update Transactions set amount ='"+transaction.getAmount()+"' Where transactionId='"+transactionId+"'";
				try{
					stt=con.prepareStatement(query);
					 stt.execute();
					}
					catch(Exception e)
					{
						e.printStackTrace();
						return false;
					}
			
			}
			
			return true;
		}
		
		
		return false;
	}
	public static Users getUser(String phoneNumber )
	{
		query="Select * from users where phoneNumber='"+phoneNumber+"'";
		try{
		stt=con.prepareStatement(query);
		rst=stt.executeQuery();
		rst.next();
		Users user=new Users();
		user.setPhoneNumber(rst.getString(1));
		user.setUserName(rst.getString(2));
		user.setPassword(rst.getString(3));
		user.setUserId(rst.getString(4));
		
		return user;
		}
		catch(Exception e)
		{
			e.getStackTrace();
			return null;
		}
		
	}
	public static Group getGroup(String groupId)
	{
		query="Select * from Group1 where groupId='"+groupId+"'";
		try{
			stt=con.prepareStatement(query);
			rst=stt.executeQuery();
			rst.next();
			Group group=new Group();
			group.setGroupId(rst.getString(1));
			group.setGroupName(rst.getString(2));
			group.setGroupTotal(rst.getString(3));
			return group;
			}
			catch(Exception e)
			{
				e.getStackTrace();
				return null;
			}
		
	}
	public static Members getMember(String groupId, String memberId)
	{
		query="Select * from Members where groupId='"+groupId+"' and memberId='"+memberId+"'";
		try{
			stt=con.prepareStatement(query);
			rst=stt.executeQuery();
			rst.next();
			Members member=new Members();
			member.setGroupId(rst.getString(1));
			member.setMemberId(rst.getString(2));
			member.setTotalOfEachMemberinGroup(rst.getString(3));
			member.setCurrenttotalOfEachMemberinGroup(rst.getString(4));
			return member;
			}
			catch(Exception e)
			{
				e.getStackTrace();
				return null;
			}
		
	}
	public static Friends getFriend(String userId, String friendId, String groupId)
	{
		
		query="Select * from Friends where userId='"+userId+"' and friendId='"+friendId+"' and groupId='"+groupId+"'";
		try{
			stt=con.prepareStatement(query);
			rst=stt.executeQuery();
			System.out.println("hello");
			rst.next();
			System.out.println(rst.getString(3));
			Friends friend=new Friends();
			friend.setUserId(rst.getString(1));
			friend.setFriendId(rst.getString(2));
			friend.setGroupId(rst.getString(3));
			friend.setOwnes(Double.parseDouble(rst.getString(4)));
			friend.setDebt(Double.parseDouble(rst.getString(5)));
			return friend;
			}
			catch(Exception e)
			{
				e.getStackTrace();
				return null;
			}
		
	}
	public Transactions getTransaction(String transactionId)
	{
		query="Select * from Transactions where transactionId='"+transactionId+"'";
		try{
			stt=con.prepareStatement(query);
			rst=stt.executeQuery();
			rst.next();
			Transactions transaction=new Transactions();
			transaction.setTransactionId(rst.getString(1));
			transaction.setGroupId(rst.getString(2));
			transaction.setMemberId(rst.getString(3));
			transaction.setDescription(rst.getString(4));
			transaction.setAmount(Double.parseDouble(rst.getString(5)));
			return transaction;
			}
			catch(Exception e)
			{
				e.getStackTrace();
				return null;
			}
		
	}	
	
	public static ResultSet get(String query)
	{   try{
		     stt=con.prepareStatement(query);
		     rst=stt.executeQuery();
		     return rst;
	       }
	     catch(Exception e)
	      {
	    	 e.getStackTrace();
	    	 return null;
	      }
	}
	
}
