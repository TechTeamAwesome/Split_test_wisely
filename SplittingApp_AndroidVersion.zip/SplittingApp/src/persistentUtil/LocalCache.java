package persistentUtil;

import java.util.HashMap;
import java.util.Map;

import models.AuthModel;
import persistentclasses.Users;

public class LocalCache {
	
	private static Map<Long ,AuthModel > user = new HashMap<>();
	
	public LocalCache() {
		
	}
	
	public static Map<Long, AuthModel> getUser() {
		return user;
	}
	
	public static String getuseridfromSessionId(long sessionid)
	{
		AuthModel lam =  user.get(sessionid);
		return lam.getUserid();
	}

	public static void setUser(Map<Long, AuthModel> user) {
		LocalCache.user = user;
	}
	
	
	

}
