package response;

public class ResponseLogin 
{
	private long sessionId;
	private String response;
	
	public ResponseLogin()
	{
		
	}

	public long getSessionId() {
		return sessionId;
	}

	public void setSessionId(long sessionId) {
		this.sessionId = sessionId;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
}
