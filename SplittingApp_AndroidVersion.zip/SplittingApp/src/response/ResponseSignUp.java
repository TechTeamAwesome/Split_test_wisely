package response;

public class ResponseSignUp 
{
	private String response;

	public ResponseSignUp()
	{
		
	}
	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
