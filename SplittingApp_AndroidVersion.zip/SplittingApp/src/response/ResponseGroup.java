package response;

import java.util.List;

public class ResponseGroup 
{
	private String groupName;
	private String groupTotal;
	private List<String> groupMembersName;
	private String response;
	
	public ResponseGroup()
	{
		
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupTotal() {
		return groupTotal;
	}

	public void setGroupTotal(String groupTotal) {
		this.groupTotal = groupTotal;
	}

	public List<String> getGroupMembersName() {
		return groupMembersName;
	}

	public void setGroupMembers(List<String> groupMembersName) {
		this.groupMembersName = groupMembersName;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
	
}
