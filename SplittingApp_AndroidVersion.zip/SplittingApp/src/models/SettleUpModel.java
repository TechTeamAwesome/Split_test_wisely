package models;

public class SettleUpModel {
	String sessionId;
	String groupId;
	String friendId;
	double amount;
	
	public SettleUpModel() {
		
	}
	
	public SettleUpModel(String sessionId, String groupId, String friendId, double amount) {
		super();
		this.sessionId = sessionId;
		this.groupId = groupId;
		this.friendId = friendId;
		this.amount = amount;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getFriendId() {
		return friendId;
	}
	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
}
