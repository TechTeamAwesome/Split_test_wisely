package models;

public class MemberModel {
	
	String groupId;
	String memberId;
	Long SessionID;

	public MemberModel(String groupId, String memberId, Long sessionID) {
		super();
		this.groupId = groupId;
		this.memberId = memberId;
		SessionID = sessionID;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public Long getSessionID() {
		return SessionID;
	}
	public void setSessionID(Long sessionID) {
		SessionID = sessionID;
	}
	

}
