package models;

public class AuthModel {
	String userid;
	
	public AuthModel() {
		
	}
	
	public AuthModel(String userid, String password) {
		super();
		this.userid = userid;
	}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	

}
