package models;

import java.util.List;

public class GroupModel {
	
	private String groupName;
	private List<Long> groupMembers;
	private long sessionID;
	
	public GroupModel() {
		
	}
	
	public GroupModel(String groupName, List<Long> groupMembers, long sessionID) {
		super();
		this.groupName = groupName;
		this.groupMembers = groupMembers;
		this.sessionID = sessionID;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public List<Long> getGroupMembers() {
		return groupMembers;
	}
	public void setGroupMembers(List<Long> groupMembers) {
		this.groupMembers = groupMembers;
	}
	public long getSessionID() {
		return sessionID;
	}
	public void setSessionID(long sessionID) {
		this.sessionID = sessionID;
	}
	
	
	
	

}
