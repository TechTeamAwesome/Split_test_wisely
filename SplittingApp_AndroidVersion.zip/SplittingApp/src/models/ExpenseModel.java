package models;

import java.util.List;

public class ExpenseModel {
	
	private long SessionId;
	private String groupId;
	private String description;
	private double amount;
	private List<Long> splitBwMembers;
	private String splitCategory;
	
	public ExpenseModel(long SessionId, String groupId, String description, double amount, String payer, List<Long> splitBwMembers, String splitCategory)
	{
		this.SessionId = SessionId;
		this.groupId = groupId;
		this.description = description;
		this.amount = amount;
		this.setSplitBwMembers(splitBwMembers);
		this.setSplitCategory(splitCategory);
	}
	
	public ExpenseModel()
	{
		
	}
	
	public long getSessionId() {
		return SessionId;
	}
	
	public void setSessionId(long SessionId) {
		this.SessionId = SessionId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getDescription() 
	{
		return description;
	}
	
	public void setDescription(String description) 
	{
		this.description = description;
	}
	
	public double getAmount() 
	{
		return amount;
	}
	
	public void setAmount(double amount) 
	{
		this.amount = amount;
	}
	
	public List<Long> getSplitBwMembers() 
	{
		return splitBwMembers;
	}

	public void setSplitBwMembers(List<Long> splitBwMembers) 
	{
		this.splitBwMembers = splitBwMembers;
	}

	public String getSplitCategory() 
	{
		return splitCategory;
	}

	public void setSplitCategory(String splitCategory) 
	{
		this.splitCategory = splitCategory;
	}
	

}
