package webservices;

import javax.json.JsonException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.*;
import models.LoginModel;
import models.MemberModel;
import models.UsersModel;
import response.ResponseGroup;
import response.ResponseLogin;
import response.ResponseSignUp;
import servicesImpl.Split_impl;
import models.ExpenseModel;
import models.GroupModel;

@Path("/user")
public class Split_services {
	
Split_impl splitinit =new Split_impl();

	
	@Path("/hello")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hello()
	{
		return "Hello World..!!";
	}

	@Path("/registration")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addUsers(UsersModel u)
	{
		
		if(splitinit.addUsers(u.getPhoneNumber(), u.getUserName(), u.getPassword(), u.getUserId()))
		{
			ResponseSignUp rs = new ResponseSignUp();
			rs.setResponse("OK");
			return Response.ok().type("application/json").entity(rs).build();
		}
		else
		{
			ResponseSignUp rs = new ResponseSignUp();
			rs.setResponse("NOT OK");
			return Response.ok().entity(rs).build();
		}
	}

	@Path("/login")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response login(LoginModel lloginmodel)
	{
		long sessionid = splitinit.login(lloginmodel.getUserId(), lloginmodel.getPassword());
		if(sessionid == -1)
		{
			ResponseLogin rs = new ResponseLogin();
			rs.setResponse("NOT OK");
			rs.setSessionId(0);
			return Response.ok().entity(rs).build();
		}
		else
		{
			ResponseLogin rs = new ResponseLogin();
			rs.setResponse("OK");
			rs.setSessionId(sessionid);
			return Response.ok().type("application/json").entity(rs).build();
		}
	}
	
	@Path("/addGroup")
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response addGroup(GroupModel lgroupModel)
	{
		ResponseGroup result= splitinit.addGroup(lgroupModel.getGroupName(),lgroupModel.getGroupMembers(),lgroupModel.getSessionID());
		return Response.status(Status.OK).type("application/json").entity(result).build();
	}
	
	@Path("/addMember")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Response addMember(MemberModel lmembermodel)
	{
		//return splitinit.addMember(lmembermodel.getGroupId(),lmembermodel.getMemberId(),lmembermodel.getSessionID());
		boolean sessionid = splitinit.addMember(lmembermodel.getGroupId(), lmembermodel.getMemberId(),lmembermodel.getSessionID());
		if(sessionid == false)
			return Response.ok().entity("Response Unsuccessful").build();
		else
			return Response.ok().type("application/json").entity("Member added Successfully").build();
	}
	
	@Path("/addExpense")
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response addExpense(ExpenseModel lexpensemodel)
	{
		String response = splitinit.addExpense(lexpensemodel.getSessionId(), lexpensemodel.getGroupId(),lexpensemodel.getDescription(), lexpensemodel.getAmount(), lexpensemodel.getSplitBwMembers(), lexpensemodel.getSplitCategory());

			return Response.ok().type("application/json").entity(response).build();
	}
//	
//	
//	@Path("/addgroups")
//	@POST
//	@Produces(MediaType.APPLICATION_JSON)
//	@Consumes(MediaType.APPLICATION_JSON)
//	public String addTransaction()
//	{
//		return splitinit.addTransction();
//	}
//	
//	
	

}
